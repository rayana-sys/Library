#pragma once
#include "Book.h"

class AudioBook : public Book{
private:
    int duration;
public:
    AudioBook(string title, string author, int year, int duration);
    int getDuration() const;

    void setDuration(int duration);
    void printInfo() const override;
    void read() override;
};