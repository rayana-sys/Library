#pragma once
#include <string>
#include "IPrintable.h"
#include "IBorrowable.h"
#include "IReadable.h"

using namespace std;

class LibraryItem : public IBorrowable, public IPrintable, public IReadable{
protected:
    string title;
    int year;
    bool available;

public:
  LibraryItem();
  LibraryItem(string title, int year);

  string getTitle() const;

  int getYear() const;
  void setTitle(string title);
  void setYear(int year);

  bool isAvailable() const override;

  void borrow() override;

  void returnItem() override;

  virtual void printInfo() const override = 0;

  virtual void read() override = 0;
  virtual ~LibraryItem(){};


};