#include "AudioBook.h"
#include <iostream>
using namespace std;

AudioBook::AudioBook(string title, string author, int year, int duration):Book(title, author, year){
    this->duration = duration;
}

int AudioBook::getDuration() const{
    return duration;
}

void AudioBook::setDuration(int duration){
    this->duration = duration;
}

void AudioBook::printInfo() const{
    cout << " AudioBook " << endl;
    Book::printInfo();
    cout << "Duration: "<< duration<< " minutes"<< endl;
}

void AudioBook::read(){
    cout << "Listening to audiobook: "<< getTitle()<< endl;
}