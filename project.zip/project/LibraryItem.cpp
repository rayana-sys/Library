#include "LibraryItem.h"
#include <iostream>
using namespace std;

LibraryItem::LibraryItem(string title, int year){
  this->title = title;
  this->year = year;
  this->available = true;
}

string LibraryItem::getTitle() const{
  return title;
}
int LibraryItem::getYear() const{
  return year;
}
bool LibraryItem::isAvailable() const{
  return available;
}
void LibraryItem::setTitle(string title){
    this->title = title;
}
void LibraryItem::setYear(int year){
    this->year = year;
}

void LibraryItem::borrow(){
  available = false;
}

void LibraryItem::returnItem(){
  available = true;
}
