#pragma once

class IBorrowable{
public:
  virtual void borrow() = 0;
  virtual void returnItem() = 0;
  virtual bool isAvailable() const = 0;

  virtual ~IBorrowable(){};
};