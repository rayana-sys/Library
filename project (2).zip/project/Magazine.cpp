#include "Magazine.h"
#include <iostream>
using namespace std;

Magazine::Magazine(string title, int issueNumber, int year) :LibraryItem(title, year){
    this->issueNumber = issueNumber;
}

int Magazine::getIssueNumber() const{
    return issueNumber;
}

void Magazine::setIssueNumber(int number){
    issueNumber = number;
}

void Magazine::printInfo() const{
    cout << " Magazine "<< endl;
    cout << "Title: "<< title<< endl;
    cout << "Issue: "<< issueNumber<< endl;
    cout << "Year: "<< year<< endl;
     cout << "Available: ";
     if (available){
         cout << "Yes";
     }
     else{
         cout << "No";
     }
     cout << endl;
}
void Magazine::read(){
    cout << "Reading magazine: "<< title << endl;
}