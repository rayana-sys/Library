#include "LibraryManager.h"
#include <iostream>
using namespace std;

LibraryManager::LibraryManager(){}
LibraryManager::~LibraryManager(){
    for (int i = 0; i < items.size(); i++)
    {
        delete items[i];
    }
}
void LibraryManager::addItem(LibraryItem* item){
    items.push_back(item);
}

void LibraryManager::showItems() const{
    if (items.empty()){
        cout << "Library is empty." << endl;
        return;
    }
    cout << endl;
    for (int i = 0; i < items.size(); i++){
        cout << "Item #" << i + 1 << endl;
        items[i]->printInfo();
        cout << endl;
    }
}

void LibraryManager::borrowItem(int index){
    if (index >= 0 && index < items.size()){
        if (items[index]->isAvailable()){
            items[index]->borrow();
            cout << "Item borrowed successfully." << endl;
        }
        else{
            cout << "Item is already borrowed." << endl;
        }
    }
    else{
        cout << "Invalid index." << endl;
    }
}

void LibraryManager::returnItem(int index){
    if (index >= 0 && index < items.size()){
        items[index]->returnItem();
        cout << "Item returned successfully." << endl;
    }
    else{
        cout << "Invalid index." << endl;
    }
}


void LibraryManager::readItem(int index){
    if (index >= 0 && index < items.size()){
        items[index]->read();
    }
    else{
        cout << "Invalid index." << endl;
    }
}