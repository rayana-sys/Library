#pragma once
#include "LibraryItem.h"

class Comic : public LibraryItem{
private:
    string artist;
public:
    Comic(string title, string artist, int year);
    string getArtist() const;
    void setArtist(string artist);
    void printInfo() const override;
    void read() override;
};