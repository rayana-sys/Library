#pragma once
#include "LibraryItem.h"
using namespace std;

class Book : public LibraryItem{
private:
  string author;
public:  
  Book();
  Book(string title, string author, int year);

  string getAuthor() const;
  void setAuthor(string author);

  void printInfo() const override;

  void read() override;

};