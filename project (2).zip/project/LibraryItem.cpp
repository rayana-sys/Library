#include "LibraryItem.h"
#include <iostream>
using namespace std;

LibraryItem::LibraryItem(string title, int year){
  this->title = title;
  this->year = year;
  this->available = true;
}

string LibraryItem::getTitle() const{
  return title;
}
int LibraryItem::getYear() const{
  return year;
}
bool LibraryItem::isAvailable() const{
  return available;
}
void LibraryItem::setTitle(string title){
    this->title = title;
}
void LibraryItem::setYear(int year){
    this->year = year;
}

void LibraryItem::borrow(){
  available = false;
}

void LibraryItem::returnItem(){
  available = true;
}

void LibraryItem::printInfo() const{
    cout << "Title: " << title << endl;
    cout << "Year: " << year << endl;
    cout << "Available: ";
    if (available){
        cout << "Yes";
    }
    else{
        cout << "No";
    }

    cout << endl;
}