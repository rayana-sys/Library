#include "Book.h"
#include <iostream>
using namespace std;

Book::Book(string title, string author, int year) : LibraryItem(title, year){
  this->author = author;
}

string Book::getAuthor() const{
  return author;
}

void Book::setAuthor(string author){
  this->author = author;
}

void Book::printInfo() const{
  cout << "Book: " << title << endl;
  cout << "Author: " << author << endl;
  cout << "Year: " << year << endl;
  cout << "Available: ";
  if (available){
    cout << "Yes";
  }
  else{
    cout << "No";
  }
  cout << endl;
}
void Book::read(){
  cout << "Reading book: " << title << endl;
}

