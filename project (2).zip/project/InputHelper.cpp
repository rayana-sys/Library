#include "InputHelper.h"
#include <iostream>
#include <limits>
using namespace std;

int inputInt(const string& prompt){
    int value;
    while (true){
        cout << prompt;
        cin >> value;
        if (cin.fail()){
            cin.clear();
            cin.ignore(
                numeric_limits<streamsize>::max(),
                '\n'
            );

            cout << "Invalid input. Please enter a number." << endl;
        }
        else{
            cin.ignore(
                numeric_limits<streamsize>::max(),
                '\n'
            );

            return value;
        }
    }
}

string inputString(const string& prompt){
    string value;
    cout << prompt;
    getline(cin, value);
    while (value.empty()){
        cout << "Invalid input. Please enter text: ";
        getline(cin, value);
    }
    return value;
}