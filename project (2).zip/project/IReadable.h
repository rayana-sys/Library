#pragma once

class IReadable{
public:
  virtual void read() = 0;
  virtual ~IReadable(){};
};
