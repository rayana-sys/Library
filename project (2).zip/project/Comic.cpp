#include "Comic.h"
#include <iostream>
using namespace std;

Comic::Comic(string title, string artist, int year): LibraryItem(title, year){
    this->artist = artist;
}
string Comic::getArtist() const{
    return artist;
}
void Comic::setArtist(string artist){
    this->artist = artist;
}

void Comic::printInfo() const{
    cout << " Comic " << endl;
    cout << "Title: "<< title<< endl;
    cout << "Artist: "<< artist<< endl;
    cout << "Year: "<< year<< endl;
     cout << "Available: ";
     if (available){
         cout << "Yes";
     }
     else{
         cout << "No";
     }
     cout << endl;
}

void Comic::read(){
    cout << "Reading comic: "<< title<< endl;
}