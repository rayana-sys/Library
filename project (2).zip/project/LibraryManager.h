#pragma once
#include <vector>
#include "LibraryItem.h"
using namespace std;

class LibraryManager{
private:
    vector<LibraryItem*> items;
public:
    LibraryManager();
    ~LibraryManager();
    void addItem(LibraryItem* item);
    void showItems() const;
    void borrowItem(int index);
    void returnItem(int index);
    void readItem(int index);
};