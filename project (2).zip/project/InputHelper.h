#pragma once

#include <string>

using namespace std;

int inputInt(const string& prompt);

string inputString(const string& prompt);