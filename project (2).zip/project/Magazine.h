#pragma once
#include "LibraryItem.h"
class Magazine : public LibraryItem{
private:
    int issueNumber;
public:
    Magazine(string title, int issueNumber, int year);
    int getIssueNumber() const;
    void setIssueNumber(int number);
    void printInfo() const override;
    void read() override;
};